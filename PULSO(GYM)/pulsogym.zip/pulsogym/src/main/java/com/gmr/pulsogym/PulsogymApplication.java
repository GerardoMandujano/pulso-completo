package com.gmr.pulsogym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PulsogymApplication {

	public static void main(String[] args) {
		SpringApplication.run(PulsogymApplication.class, args);
	}

}
